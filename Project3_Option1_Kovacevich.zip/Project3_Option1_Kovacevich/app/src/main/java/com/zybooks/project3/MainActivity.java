package com.zybooks.project3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Not in use
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}